#! /bin/sh

mdbook build
