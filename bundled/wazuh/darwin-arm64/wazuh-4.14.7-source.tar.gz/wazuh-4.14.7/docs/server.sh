#! /bin/sh

mdbook serve
